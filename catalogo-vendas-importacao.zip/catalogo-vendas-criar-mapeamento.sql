/* Rode este arquivo UMA ÚNICA VEZ contra a base de DESTINO, antes de
   rodar o catalogo-vendas-insert.sql pela primeira vez.

   Se rodar de novo (ou rodar contra uma base onde a tabela já existe),
   vai dar erro "Table ZZ_CATALOGO_IMPORT_MAP already exists" — isso é
   esperado e inofensivo, só ignore.

   Essa tabela guarda o mapeamento CODIGO_ORIGEM (código do item na sua
   base) -> CODIGO_DESTINO (código novo, alocado na base de destino) —
   é o que garante que o catalogo-vendas-insert.sql nunca reaproveita o
   código de um item que já existe na base de destino. Pode deixar essa
   tabela no banco depois de importar (serve de log de para onde cada
   item foi parar) ou apagar com DROP TABLE ZZ_CATALOGO_IMPORT_MAP
   quando não precisar mais. */

CREATE TABLE ZZ_CATALOGO_IMPORT_MAP (
  CODIGO_ORIGEM INTEGER NOT NULL,
  CODIGO_DESTINO INTEGER NOT NULL,
  CONSTRAINT PK_ZZ_CATALOGO_IMPORT_MAP PRIMARY KEY (CODIGO_ORIGEM)
);
