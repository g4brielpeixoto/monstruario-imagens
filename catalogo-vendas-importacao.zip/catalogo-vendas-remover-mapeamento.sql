/* Rode este arquivo contra a base de DESTINO depois de confirmar que a
   importação do catálogo está correta (itens, detalhes e imagens
   aparecendo certinho). Remove a tabela auxiliar ZZ_CATALOGO_IMPORT_MAP —
   ela não é parte do sistema, só serviu pra garantir que nenhum código de
   item existente fosse reaproveitado durante a importação.

   IMPORTANTE: depois de rodar isto, o catalogo-vendas-insert.sql não pode
   mais ser reexecutado contra esta base (ele depende da tabela pra saber
   quais itens já foram importados e evitar duplicar). Só rode este
   arquivo quando tiver certeza de que não vai precisar rodar a
   importação de novo nesta base. */

DROP TABLE ZZ_CATALOGO_IMPORT_MAP;
