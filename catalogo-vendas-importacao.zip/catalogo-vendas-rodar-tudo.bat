@echo off
setlocal enabledelayedexpansion

rem ============================================================
rem Roda a importacao do catalogo/mostruario contra o banco de DESTINO:
rem   1) Cria a tabela de mapeamento (se ainda nao existir)
rem   2) Roda o catalogo-vendas-insert.sql (ja gerado, estatico)
rem
rem So precisa desses arquivos na mesma pasta que este .bat:
rem   - catalogo-vendas-criar-mapeamento.sql
rem   - catalogo-vendas-insert.sql
rem   - catalogo-vendas-remover-mapeamento.sql (usado depois, manualmente)
rem
rem NAO roda o catalogo-vendas-remover-mapeamento.sql automaticamente
rem de proposito -- isso e' o ultimo passo, so depois de voce conferir
rem visualmente que os itens/mostruario/imagens entraram certo.
rem ============================================================

set "SCRIPT_DIR=%~dp0"
set "ISQL=C:\Program Files\Firebird\Firebird_4_0\isql.exe"
set "CRIAR_MAPEAMENTO=%SCRIPT_DIR%catalogo-vendas-criar-mapeamento.sql"
set "INSERT_SQL=%SCRIPT_DIR%catalogo-vendas-insert.sql"
set "LOG_CRIACAO=%SCRIPT_DIR%log-criacao-mapeamento.log"
set "LOG_RESULTADO=%SCRIPT_DIR%catalogo-vendas-resultado.log"

if not exist "%ISQL%" (
  set "ISQL=C:\Program Files\Firebird\Firebird_3_0\isql.exe"
)
if not exist "%ISQL%" (
  echo ERRO: isql.exe nao encontrado em Firebird_4_0 nem Firebird_3_0.
  set /p "ISQL=Informe o caminho completo do isql.exe: "
)
if not exist "%ISQL%" (
  echo ERRO: "%ISQL%" nao existe. Abortando.
  goto :fim
)

if not exist "%CRIAR_MAPEAMENTO%" (
  echo ERRO: %CRIAR_MAPEAMENTO% nao encontrado. Este .bat precisa estar na
  echo mesma pasta que os arquivos catalogo-vendas-*.sql.
  goto :fim
)
if not exist "%INSERT_SQL%" (
  echo ERRO: %INSERT_SQL% nao encontrado. Este .bat precisa estar na
  echo mesma pasta que os arquivos catalogo-vendas-*.sql.
  goto :fim
)

echo ============================================================
echo  Importacao do catalogo/mostruario
echo ============================================================
echo.
set /p "TARGET_CONN=Conexao do banco de DESTINO (host/porta:caminho): "
if "%TARGET_CONN%"=="" (
  echo Nenhuma conexao informada. Abortando.
  goto :fim
)
set /p "DBUSER=Usuario [SYSDBA]: "
if "%DBUSER%"=="" set "DBUSER=SYSDBA"
set /p "DBPASS=Senha [masterkey]: "
if "%DBPASS%"=="" set "DBPASS=masterkey"

echo.
echo  DESTINO: %TARGET_CONN%
echo  USUARIO: %DBUSER%
echo ============================================================
echo.
echo Confere se esta correto antes de continuar -- isso vai gravar
echo dados nesse banco.
pause

echo.
echo === Passo 1/2: criando tabela de mapeamento no DESTINO ===
"%ISQL%" -i "%CRIAR_MAPEAMENTO%" -user %DBUSER% -password %DBPASS% -ch ISO8859_1 "%TARGET_CONN%" > "%LOG_CRIACAO%" 2>&1
type "%LOG_CRIACAO%"
echo (erro "already exists" aqui e esperado numa reexecucao -- ignore)

echo.
echo === Passo 2/2: rodando o insert.sql contra o DESTINO ===
del /q "%LOG_RESULTADO%" 2>nul
"%ISQL%" -i "%INSERT_SQL%" -o "%LOG_RESULTADO%" -user %DBUSER% -password %DBPASS% -ch ISO8859_1 "%TARGET_CONN%"

echo.
echo ============================================================
for %%F in ("%LOG_RESULTADO%") do set "LOG_SIZE=%%~zF"
if "!LOG_SIZE!"=="0" (
  echo SUCESSO: log de resultado vazio, nenhum erro reportado.
) else (
  echo ATENCAO: o log de resultado NAO esta vazio -- confira:
  echo   %LOG_RESULTADO%
  type "%LOG_RESULTADO%"
)
echo ============================================================
echo.
echo Confira visualmente no DESTINO se os itens/mostruario/imagens
echo entraram certo antes de rodar catalogo-vendas-remover-mapeamento.sql
echo ^(esse passo final NAO e' automatico de proposito^).

:fim
echo.
pause
